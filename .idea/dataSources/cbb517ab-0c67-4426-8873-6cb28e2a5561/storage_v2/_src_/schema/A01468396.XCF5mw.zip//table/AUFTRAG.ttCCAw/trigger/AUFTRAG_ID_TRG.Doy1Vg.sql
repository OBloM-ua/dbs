CREATE TRIGGER AUFTRAG_ID_TRG
  BEFORE INSERT
  ON AUFTRAG
  FOR EACH ROW
  BEGIN
    IF :new.Auftragid IS NULL
    THEN
      SELECT auftrag_seq.nextval
      INTO :new.Auftragid
      FROM dual;
    END IF;
  END;
/

